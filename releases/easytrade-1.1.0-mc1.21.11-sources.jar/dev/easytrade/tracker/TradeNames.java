package dev.easytrade.tracker;

import it.unimi.dsi.fastutil.objects.Object2IntMap;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1646;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1887;
import net.minecraft.class_1914;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3988;
import net.minecraft.class_3989;
import net.minecraft.class_7923;
import net.minecraft.class_9304;
import net.minecraft.class_9334;

public final class TradeNames {

	private TradeNames() {
	}

	public static String costTotal(List<class_1914> offers) {
		Map<String, Integer> totals = new LinkedHashMap<>();
		for (class_1914 offer : offers) {
			addCost(totals, offer.method_8246());
			class_1799 b = offer.method_8247();
			if (!b.method_7960()) {
				addCost(totals, b);
			}
		}
		if (totals.isEmpty()) {
			return "";
		}
		StringBuilder sb = new StringBuilder();
		for (Map.Entry<String, Integer> entry : totals.entrySet()) {
			if (sb.length() > 0) {
				sb.append(" + ");
			}
			sb.append(entry.getValue()).append(' ').append(entry.getKey());
			if (entry.getValue() != 1) {
				sb.append('s');
			}
		}
		return sb.toString();
	}

	private static void addCost(Map<String, Integer> totals, class_1799 stack) {
		totals.merge(stack.method_7964().getString(), stack.method_7947(), Integer::sum);
	}

	public static String offerSignature(class_1914 offer) {
		StringBuilder sb = new StringBuilder();
		sb.append(itemKey(offer.method_8250())).append(':').append(offer.method_8250().method_7947());
class_9304 ench = enchantmentsOf(offer.method_8250());
		for (Object2IntMap.Entry<net.minecraft.class_6880<class_1887>> entry : ench.method_57539()) {
			sb.append('~').append(entry.getKey().method_40230().map(k -> k.method_29177().toString()).orElse("?"))
				.append(':').append(entry.getIntValue());
		}
		sb.append('|').append(itemKey(offer.method_8246())).append(':').append(offer.method_8246().method_7947());
		if (!offer.method_8247().method_7960()) {
			sb.append('|').append(itemKey(offer.method_8247())).append(':').append(offer.method_8247().method_7947());
		}
		return sb.toString();
	}

	private static String itemKey(class_1799 stack) {
		class_2960 key = class_7923.field_41178.method_10221(stack.method_7909());
		return key != null ? key.toString() : "?";
	}

	public static class_9304 enchantmentsOf(class_1799 stack) {
		if (stack.method_31574(class_1802.field_8598)) {
			return stack.method_58695(class_9334.field_49643, class_9304.field_49385);
		}
		return stack.method_58657();
	}

	public static String offerTitle(class_1914 offer) {
		class_1799 out = offer.method_8250();
		if (out.method_7960()) {
			return "?";
		}
		class_9304 enchantments = enchantmentsOf(out);
		if (!enchantments.method_57543()) {
			Iterator<Object2IntMap.Entry<net.minecraft.class_6880<class_1887>>> it = enchantments.method_57539().iterator();
			Object2IntMap.Entry<net.minecraft.class_6880<class_1887>> first = it.next();
			class_2561 name = class_1887.method_8179(first.getKey(), first.getIntValue());
			if (it.hasNext()) {
				name = name.method_27661().method_27693(" +");
			}
			return name.getString();
		}
		return out.method_7964().getString();
	}

	public static String emeraldCost(class_1914 offer) {
		int total = 0;
		boolean any = false;
		class_1799 a = offer.method_8246();
		if (a.method_31574(class_1802.field_8687)) {
			total += a.method_7947();
			any = true;
		}
		class_1799 b = offer.method_8247();
		if (!b.method_7960() && b.method_31574(class_1802.field_8687)) {
			total += b.method_7947();
			any = true;
		}
		return any ? Integer.toString(total) : "";
	}

	public static String villagerTitle(class_3988 villager) {
		if (villager instanceof class_3989) {
			return "Wandering Trader";
		}
		if (villager instanceof class_1646 v) {
			String profession = v.method_7231().comp_3521().comp_349().comp_818().getString();
			if (profession == null || profession.isEmpty()) {
				profession = "Villager";
			}
			return profession;
		}
		return "Villager";
	}
}