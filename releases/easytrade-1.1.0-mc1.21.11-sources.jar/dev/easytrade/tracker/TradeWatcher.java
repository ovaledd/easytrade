package dev.easytrade.tracker;

import dev.easytrade.config.DesiredTrade;
import dev.easytrade.config.ModConfig;
import dev.easytrade.render.PanelRenderer;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.class_10799;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1728;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1914;
import net.minecraft.class_1916;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2815;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3417;
import net.minecraft.class_3988;
import net.minecraft.class_5575;
import net.minecraft.class_746;

public final class TradeWatcher {

	private static final double MAX_RANGE = 3.0;
	private static final double MAX_ANGLE_COS = Math.cos(Math.toRadians(13.0));
	private static final int PEEK_TIMEOUT_TICKS = 60;
	private static final int DISPLAY_FADE_TICKS = 40;
	private static final int MAX_CELLS = 16;
	private static final int MANUAL_SUPPRESS_TICKS = 10;
	private static final int MAX_PINS = 4;
	private static final int TOAST_TICKS = 60;
	private static final int TOAST_FADE_TICKS = 20;
	private static final int COLOR_TOAST_GREEN = 0x55FF55;
	private static final int COLOR_TOAST_MAROON = 0x8B0000;

	private static boolean peekMode = false;
	private static boolean peekInteract = false;
	private static long manualInteractTick = -100;

	public static boolean isPeeking() {
		return peekMode;
	}

	public static boolean isPeekInteract() {
		return peekInteract;
	}

	public static void onPlayerInteract() {
		peekMode = false;
		peekTicks = 0;
		pendingVillager = null;
		class_310 mc = class_310.method_1551();
		if (mc.field_1687 != null) {
			manualInteractTick = mc.field_1687.method_75260();
		}
	}

	public static void openPeekContainer(int containerId) {
		class_310 mc = class_310.method_1551();
		if (mc.field_1724 == null) {
			return;
		}
		mc.field_1724.field_7512 = new class_1728(containerId, mc.field_1724.method_31548());
	}

	private static void closePeekContainer(class_746 player) {
		if (player.field_7512 instanceof class_1728 menu) {
			player.field_3944.method_52787(new class_2815(menu.field_7763));
			player.field_7512 = player.field_7498;
		}
	}

	private static int peekTicks = 0;
	private static class_3988 pendingVillager = null;
	private static int pollCounter = 0;
	private static PeekData data = null;
	private static class_243 anchor = null;
	private static int currentVillagerId = -1;
	private static long lastPeekTick = -100;
	private static final Set<String> alertedMatches = new HashSet<>();

	private record PinnedTrade(int villagerId, String signature, PeekData data) {
	}

	private record InvButton(int x, int y, int w, int h, int index) {
	}

	private static final List<PinnedTrade> pinnedTrades = new ArrayList<>();
	private static final List<InvButton> invButtons = new ArrayList<>();
	private static String toastText = null;
	private static int toastColor = COLOR_TOAST_GREEN;
	private static long toastExpireTick = 0;

	private TradeWatcher() {
	}

	private static void showToast(String text, int color) {
		toastText = text;
		toastColor = color;
		class_310 mc = class_310.method_1551();
		toastExpireTick = mc.field_1687 != null ? mc.field_1687.method_75260() + TOAST_TICKS : 0;
	}

	public static void tick(class_310 client) {
		if (client == null || client.field_1724 == null || client.field_1687 == null) {
			reset();
			return;
		}
		class_746 player = client.field_1724;

		if (peekMode) {
			peekTicks++;
			if (peekTicks > PEEK_TIMEOUT_TICKS) {
				peekMode = false;
				pendingVillager = null;
				closePeekContainer(player);
			}
			return;
		}

		if (client.field_1755 != null) {
			return;
		}
		if (player.method_5715() || player.method_7325() || player.method_29504()) {
			return;
		}
		if (player.field_7512 != player.field_7498) {
			return;
		}
		if (client.field_1687.method_75260() - manualInteractTick < MANUAL_SUPPRESS_TICKS) {
			return;
		}

		class_3988 target = findTarget(client, player);
		if (target == null) {
			return;
		}

		int interval = (data != null && currentVillagerId != target.method_5628())
			? 1
			: ModConfig.INSTANCE.pollIntervalTicks;
		if (++pollCounter < interval) {
			return;
		}
		pollCounter = 0;
		if (data == null && lastPeekTick >= 0 && client.field_1687.method_75260() - lastPeekTick < 2) {
			return;
		}

		if (client.field_1761 == null) {
			return;
		}
		peekMode = true;
		peekTicks = 0;
		pendingVillager = target;
		lastPeekTick = client.field_1687.method_75260();
		peekInteract = true;
		client.field_1761.method_2905(player, target, class_1268.field_5808);
		peekInteract = false;
	}

	private static class_3988 findTarget(class_310 client, class_746 player) {
		class_243 eye = player.method_33571();
		class_238 box = new class_238(eye, eye).method_1014(MAX_RANGE);
		List<class_3988> villagers = client.field_1687.method_18023(
			class_5575.method_31795(class_3988.class),
			box,
			v -> v.method_5805() && !v.method_31481());
		class_243 view = player.method_5828(1.0f);
		class_3988 best = null;
		double bestScore = Double.MAX_VALUE;
		for (class_3988 v : villagers) {
			class_243 to = v.method_33571().method_1020(eye).method_1029();
			double cos = to.method_1026(view);
			if (cos < MAX_ANGLE_COS) {
				continue;
			}
			double dist = v.method_33571().method_1025(eye);
			if (dist > MAX_RANGE * MAX_RANGE) {
				continue;
			}
			double score = dist / cos;
			if (score < bestScore) {
				bestScore = score;
				best = v;
			}
		}
		return best;
	}

	public static void onOffersReceived() {
		if (!peekMode) {
			return;
		}
		class_310 mc = class_310.method_1551();
		class_746 player = mc.field_1724;
		if (player == null || mc.field_1687 == null) {
			return;
		}
		peekMode = false;
		peekTicks = 0;
		class_3988 villager = pendingVillager;
		pendingVillager = null;
		if (player.field_7512 instanceof class_1728 menu) {
			processOffers(menu.method_17438(), menu.method_19258(), player, villager);
		}
		closePeekContainer(player);
	}

	private static boolean isBookTrade(class_1914 offer) {
		class_1799 result = offer.method_8250();
		return result.method_31574(class_1802.field_8598) || result.method_31574(class_1802.field_8529);
	}

	private static void processOffers(class_1916 offers, int merchantLevel, class_746 player, class_3988 villager) {
		if (villager == null || offers.isEmpty()) {
			clearDisplay();
			return;
		}
		ModConfig cfg = ModConfig.INSTANCE;
		String title = TradeNames.villagerTitle(villager);
		List<PeekData.OfferLine> lines = new ArrayList<>();
		List<class_1914> matchedOffers = new ArrayList<>();

		List<class_1914> ordered = new ArrayList<>();
		for (class_1914 offer : offers) {
			if (isBookTrade(offer)) {
				ordered.add(offer);
			}
		}
		for (class_1914 offer : offers) {
			if (!isBookTrade(offer)) {
				ordered.add(offer);
			}
		}

		class_1914 main = ordered.get(0);
		if (wants(main, cfg, player, villager)) {
			matchedOffers.add(main);
		}

		String levelText = merchantLevel > 0 ? "Level " + merchantLevel + "  " : "";
		String itemName = TradeNames.offerTitle(main);
		class_1799 mainIcon = main.method_8250();
		String mainCost = TradeNames.costTotal(List.of(main));
		class_1799 costA = main.method_8246();
		class_1799 costB = main.method_8247();

		for (int i = 1; i < ordered.size() && lines.size() < MAX_CELLS; i++) {
			class_1914 offer = ordered.get(i);
			boolean m = wants(offer, cfg, player, villager);
			if (m) {
				matchedOffers.add(offer);
			}
			lines.add(new PeekData.OfferLine(TradeNames.offerTitle(offer), offer.method_8250(), m,
				m ? TradeNames.emeraldCost(offer) : ""));
		}

		String price = matchedOffers.isEmpty() ? "" : TradeNames.costTotal(matchedOffers);

		if (alertedMatches.size() > 1000) {
			alertedMatches.clear();
		}
		anchor = villager.method_73189().method_1031(0, villager.method_17682() + 0.5, 0);
		currentVillagerId = villager.method_5628();
		data = new PeekData(title, levelText, itemName, price, mainCost, mainIcon, costA, costB, lines,
			!matchedOffers.isEmpty(), player.method_73183().method_75260());
	}

	private static boolean wants(class_1914 offer, ModConfig cfg, class_746 player, class_3988 villager) {
		for (DesiredTrade want : cfg.desiredTrades) {
			if (want.matches(offer.method_8250())) {
				String sigKey = villager.method_5667() + "|" + TradeNames.offerSignature(offer);
				if (cfg.alertSound && alertedMatches.add(sigKey)) {
					player.method_5783(class_3417.field_14627, 1.0f, 1.0f);
				}
				return true;
			}
		}
		return false;
	}

	public static void pinOffer(class_1914 offer) {
		class_310 mc = class_310.method_1551();
		if (mc.field_1724 == null || mc.field_1687 == null) {
			return;
		}
		class_3988 villager = findTarget(mc, mc.field_1724);
		if (villager == null && currentVillagerId >= 0) {
			class_1297 e = mc.field_1687.method_8469(currentVillagerId);
			if (e instanceof class_3988 v && v.method_5805()) {
				villager = v;
			}
		}
		if (villager == null) {
			return;
		}
		String signature = TradeNames.offerSignature(offer);
		for (PinnedTrade pin : pinnedTrades) {
			if (pin.villagerId() == villager.method_5628() && pin.signature().equals(signature)) {
				return;
			}
		}
		if (pinnedTrades.size() >= MAX_PINS) {
			showToast("You have reached the maximum pinned trades!", COLOR_TOAST_MAROON);
			return;
		}
		PeekData d = new PeekData(TradeNames.villagerTitle(villager), "", TradeNames.offerTitle(offer), "",
			TradeNames.costTotal(List.of(offer)), offer.method_8250(), offer.method_8246(), offer.method_8247(),
			List.of(), false, mc.field_1687.method_75260());
		pinnedTrades.add(new PinnedTrade(villager.method_5628(), signature, d));
		showToast("Trade pinned successfully", COLOR_TOAST_GREEN);
	}

	public static void renderToast(class_332 graphics) {
		if (toastText == null) {
			return;
		}
		class_310 mc = class_310.method_1551();
		if (mc.field_1687 == null) {
			toastText = null;
			return;
		}
		long remaining = toastExpireTick - mc.field_1687.method_75260();
		if (remaining <= 0) {
			toastText = null;
			return;
		}
		int alpha = 255;
		if (remaining < TOAST_FADE_TICKS) {
			alpha = (int) (255 * remaining / (double) TOAST_FADE_TICKS);
		}
		int color = (alpha << 24) | toastColor;
		int w = mc.field_1772.method_1727(toastText);
		int x = (graphics.method_51421() - w) / 2;
		int y = graphics.method_51443() - 62;
		graphics.method_25303(mc.field_1772, toastText, x, y, color);
	}

	public static void renderInventoryOverlay(class_332 graphics, int containerLeft, int containerTop,
		int containerWidth) {
		class_310 mc = class_310.method_1551();
		if (mc == null || mc.field_1724 == null || mc.field_1687 == null) {
			return;
		}
		class_746 player = mc.field_1724;
		invButtons.clear();
		int gw = graphics.method_51421();
		int x = containerLeft + containerWidth + 8;
		int maxX = gw - PanelRenderer.PANEL_WIDTH - 4;
		if (x > maxX) {
			x = Math.max(containerLeft + containerWidth + 4, maxX);
		}
		if (x < 4) {
			return;
		}
		int y = containerTop;
		for (int i = 0; i < pinnedTrades.size(); i++) {
			PinnedTrade pin = pinnedTrades.get(i);
			y = drawInventoryCard(graphics, mc, player, pin.data(), x, y, i);
			y += 8;
		}
	}

	private static int drawInventoryCard(class_332 graphics, class_310 mc, class_746 player, PeekData d,
		int x, int y, int index) {
		int w = PanelRenderer.PANEL_WIDTH;
		int h = 54;
		boolean affordable = canAfford(player, d.costA(), d.costB());
		int bgColor = ((int) (255 * PanelRenderer.BG_ALPHA) << 24) | 0xFFFFFF;
		int frameColor = ((int) (255 * PanelRenderer.FRAME_ALPHA) << 24)
			| (affordable ? PanelRenderer.TINT_MATCH : 0xFFFFFF);
		graphics.method_52707(class_10799.field_56883, PanelRenderer.TOOLTIP_BACKGROUND, x, y, w, h, bgColor);
		graphics.method_52707(class_10799.field_56883, PanelRenderer.TOOLTIP_FRAME, x, y, w, h, frameColor);

		int buttonX = x + w - 22;
		int buttonY = y + 4;
		graphics.method_25294(buttonX, buttonY, buttonX + 14, buttonY + 10, 0x66000000);
		graphics.method_25303(mc.field_1772, "X", buttonX + (14 - mc.field_1772.method_1727("X")) / 2, buttonY + 1, 0xFFFF6B6B);
		invButtons.add(new InvButton(buttonX, buttonY, 14, 10, index));

		String title = d.title();
		graphics.method_25303(mc.field_1772, title, x + 8, y + 4, d.matched() ? PanelRenderer.COLOR_MATCH : PanelRenderer.COLOR_TITLE);

		graphics.method_51427(d.mainIcon(), x + 8, y + 20);
		String itemName = d.itemName();
		int nameColor;
		if (d.matched()) {
			nameColor = PanelRenderer.COLOR_MATCH;
		} else if (d.mainIcon().method_31574(class_1802.field_8598)) {
			nameColor = PanelRenderer.rainbowColor(mc.field_1687.method_75260(), 255);
		} else {
			nameColor = PanelRenderer.COLOR_DETAIL;
		}
		graphics.method_25303(mc.field_1772, itemName, x + 28, y + 25, nameColor);

		String cost = d.mainCost();
		graphics.method_25303(mc.field_1772, cost, x + 8, y + 40, affordable ? PanelRenderer.COLOR_MATCH : PanelRenderer.COLOR_DETAIL);
		return y + h;
	}

	public static boolean handleInventoryClick(int mx, int my) {
		for (InvButton b : invButtons) {
			if (mx >= b.x() && mx < b.x() + b.w() && my >= b.y() && my < b.y() + b.h()) {
				unpin(b.index());
				return true;
			}
		}
		return false;
	}

	private static void unpin(int index) {
		if (index >= 0 && index < pinnedTrades.size()) {
			pinnedTrades.remove(index);
		}
	}

	private static boolean canAfford(class_746 player, class_1799 costA, class_1799 costB) {
		if (!costA.method_7960() && countItem(player, costA.method_7909()) < costA.method_7947()) {
			return false;
		}
		return costB.method_7960() || countItem(player, costB.method_7909()) >= costB.method_7947();
	}

	private static int countItem(class_746 player, class_1792 item) {
		int total = 0;
		for (class_1799 stack : player.method_31548().method_67533()) {
			if (stack.method_31574(item)) {
				total += stack.method_7947();
			}
		}
		class_1799 offhand = player.method_31548().method_5438(net.minecraft.class_1661.field_30639);
		if (offhand.method_31574(item)) {
			total += offhand.method_7947();
		}
		return total;
	}

	public static void render(class_332 graphics) {
		class_310 mc = class_310.method_1551();
		if (mc == null || mc.field_1724 == null || mc.field_1687 == null || mc.field_1755 != null) {
			return;
		}
		PeekData d = data;
		if (d == null || anchor == null) {
			return;
		}
		if (mc.field_1687.method_75260() - d.seenAtTick() > DISPLAY_FADE_TICKS) {
			return;
		}

		class_243 head = anchor;
		if (currentVillagerId >= 0) {
			class_1297 villager = mc.field_1687.method_8469(currentVillagerId);
			if (villager != null && villager.method_5805()) {
				head = villager.method_73189().method_1031(0, villager.method_17682() + 0.5, 0);
			}
		}

		double dx = head.field_1352 - mc.field_1724.method_73189().field_1352;
		double dz = head.field_1350 - mc.field_1724.method_73189().field_1350;
		if (dx * dx + dz * dz > MAX_RANGE * MAX_RANGE) {
			return;
		}

		PanelRenderer.render(graphics, mc, d, head);
	}

	private static void clearDisplay() {
		data = null;
		anchor = null;
		currentVillagerId = -1;
	}

	private static void reset() {
		peekMode = false;
		peekTicks = 0;
		pendingVillager = null;
		pollCounter = 0;
		pinnedTrades.clear();
		invButtons.clear();
		clearDisplay();
	}
}