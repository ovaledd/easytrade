package dev.easytrade.util;

import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector4f;

public record ScreenPos(float x, float y) {

	public static ScreenPos project(class_310 mc, class_243 worldPos) {
		class_4184 cam = mc.field_1773.method_19418();
		Matrix4f viewRotation = new Matrix4f().rotation(cam.method_23767().conjugate(new Quaternionf()));
		Matrix4f mvp = mc.field_1773.method_22973(mc.field_1690.method_41808().method_41753()).mul(viewRotation);
		class_243 rel = worldPos.method_1020(cam.method_71156());
		Vector4f clip = new Vector4f((float) rel.field_1352, (float) rel.field_1351, (float) rel.field_1350, 1.0f).mul(mvp);
		if (clip.w <= 0.01f) {
			return null;
		}
		float ndcX = clip.x / clip.w;
		float ndcY = clip.y / clip.w;
		if (ndcX < -1.5f || ndcX > 1.5f || ndcY < -1.5f || ndcY > 1.5f) {
			return null;
		}
		int gw = mc.method_22683().method_4486();
		int gh = mc.method_22683().method_4502();
		float sx = (ndcX * 0.5f + 0.5f) * gw;
		float sy = (0.5f - ndcY * 0.5f) * gh;
		return new ScreenPos(sx, sy);
	}
}