package dev.easytrade.gui;

import dev.easytrade.config.DesiredTrade;
import dev.easytrade.config.ModConfig;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_437;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class TradeSelectScreen extends class_437 {

	private static final int RESULTS_CAP = 48;
	private static final int ROW_HEIGHT = 16;
	private static final int COLOR_TITLE = 0xFFFFFFFF;
	private static final int COLOR_HEADER = 0xFFA8A8B3;
	private static final int COLOR_TEXT = 0xFFE4E4E9;
	private static final int COLOR_MUTED = 0xFF70707A;
	private static final int COLOR_X = 0xFFFF6B6B;

	private class_342 searchBox;
	private String query = "";
	private List<ResultEntry> results = new ArrayList<>();

	private record ResultEntry(String label, DesiredTrade trade, class_1799 icon) {
	}

	public TradeSelectScreen() {
		super(class_2561.method_43470("Easy Trade"));
	}

	@Override
	protected void method_25426() {
		this.searchBox = new class_342(this.field_22793, this.field_22789 / 2 - 130, 26, 260, 18, class_2561.method_43471("easytrade.search.hint"));
		this.searchBox.method_1880(64);
		this.searchBox.method_47404(class_2561.method_43471("easytrade.search.hint"));
		this.searchBox.method_1863(q -> {
			this.query = q == null ? "" : q.trim().toLowerCase(Locale.ROOT);
			this.refreshResults();
		});
		this.method_37063(this.searchBox);
		this.refreshResults();
	}

	@Override
	protected void method_56131() {
		this.method_48265(this.searchBox);
	}

	private void refreshResults() {
		List<ResultEntry> entries = new ArrayList<>();
		class_310 mc = class_310.method_1551();

		for (class_2960 id : class_7923.field_41178.method_10235()) {
			if (id.method_12832().equals("air")) {
				continue;
			}
			var item = class_7923.field_41178.method_63535(id);
			if (item == class_1802.field_8162) {
				continue;
			}
			class_1799 stack = new class_1799(item);
			String label = stack.method_7964().getString();
			if (matchesQuery(id.toString(), label)) {
				entries.add(new ResultEntry(label, new DesiredTrade("item", id.toString(), 0), stack));
				if (entries.size() >= RESULTS_CAP) {
					break;
				}
			}
		}

		if (entries.size() < RESULTS_CAP && mc.field_1687 != null) {
			mc.field_1687.method_30349().method_30530(class_7924.field_41265).method_42017().forEach(holder -> {
				if (entries.size() >= RESULTS_CAP) {
					return;
				}
				class_2960 id = holder.method_40237().method_29177();
				String label = holder.comp_349().comp_2686().getString();
				if (matchesQuery(id.toString(), label)) {
					class_1799 book = new class_1799(class_1802.field_8598);
					entries.add(new ResultEntry(label, new DesiredTrade("enchantment", id.toString(), 0), book));
				}
			});
		}

		this.results = entries;
	}

	private boolean matchesQuery(String id, String label) {
		if (this.query.isEmpty()) {
			return false;
		}
		return id.toLowerCase(Locale.ROOT).contains(this.query) || label.toLowerCase(Locale.ROOT).contains(this.query);
	}

	@Override
	public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
		graphics.method_25294(0, 0, this.field_22789, this.field_22790, 0x9910141A);

		super.method_25394(graphics, mouseX, mouseY, delta);

		class_2561 title = class_2561.method_43471("easytrade.screen.title");
		graphics.method_27535(this.field_22793, title, this.field_22789 / 2 - this.field_22793.method_27525(title) / 2, 8, COLOR_TITLE);

		int colX = 16;
		int colW = 300;
		class_2561 wantedHeader = class_2561.method_43471("easytrade.screen.wanted");
		graphics.method_27535(this.field_22793, wantedHeader, colX, 50, COLOR_HEADER);
		int y = 66;
		for (DesiredTrade trade : ModConfig.INSTANCE.desiredTrades) {
			graphics.method_27535(this.field_22793, class_2561.method_43470("X"), colX + 4, y + 1, COLOR_X);
			graphics.method_27535(this.field_22793, class_2561.method_43470(labelOf(trade)), colX + 20, y + 2, COLOR_TEXT);
			y += ROW_HEIGHT;
		}
		if (ModConfig.INSTANCE.desiredTrades.isEmpty()) {
			String none = class_2561.method_43471("easytrade.screen.none").getString();
			graphics.method_25303(this.field_22793, none, colX + colW / 2 - this.field_22793.method_1727(none) / 2, y + 2, COLOR_MUTED);
		}

		int resX = colX + colW + 24;
		int resW = this.field_22789 - resX - 16;
		class_2561 resultsHeader = class_2561.method_43471("easytrade.screen.results");
		graphics.method_27535(this.field_22793, resultsHeader, resX, 50, COLOR_HEADER);
		if (this.query.isEmpty()) {
			String hint = class_2561.method_43471("easytrade.screen.typehint").getString();
			graphics.method_25303(this.field_22793, hint, resX + resW / 2 - this.field_22793.method_1727(hint) / 2, 70, COLOR_MUTED);
		} else {
			int ry = 66;
			for (ResultEntry entry : this.results) {
				graphics.method_51427(entry.icon(), resX, ry);
				graphics.method_27535(this.field_22793, class_2561.method_43470(entry.label()), resX + 20, ry + 4, COLOR_TEXT);
				ry += ROW_HEIGHT;
			}
			if (this.results.isEmpty()) {
				String noMatch = class_2561.method_43471("easytrade.screen.nomatch").getString();
				graphics.method_25303(this.field_22793, noMatch, resX + resW / 2 - this.field_22793.method_1727(noMatch) / 2, 70, COLOR_MUTED);
			}
		}

		String hint = class_2561.method_43471("easytrade.screen.hint").getString();
		graphics.method_25303(this.field_22793, hint, this.field_22789 / 2 - this.field_22793.method_1727(hint) / 2, this.field_22790 - 14, COLOR_MUTED);
	}

	@Override
	public boolean method_25402(class_11909 event, boolean doubleClicked) {
		if (event.comp_4800().comp_4801() == 0) {
			int mx = (int) event.comp_4798();
			int my = (int) event.comp_4799();

			int colX = 16;
			int y = 66;
			int idx = 0;
			List<DesiredTrade> wanted = ModConfig.INSTANCE.desiredTrades;
			for (DesiredTrade trade : wanted) {
				if (mx >= colX && mx <= colX + 16 && my >= y && my <= y + ROW_HEIGHT) {
					wanted.remove(idx);
					ModConfig.save();
					return true;
				}
				idx++;
				y += ROW_HEIGHT;
			}

			int resX = colX + 324;
			int ry = 66;
			for (ResultEntry entry : this.results) {
				if (mx >= resX && mx <= resX + 260 && my >= ry && my <= ry + ROW_HEIGHT) {
					addWanted(entry.trade());
					return true;
				}
				ry += ROW_HEIGHT;
			}
		}
		return super.method_25402(event, doubleClicked);
	}

	private void addWanted(DesiredTrade trade) {
		List<DesiredTrade> wanted = ModConfig.INSTANCE.desiredTrades;
		for (DesiredTrade existing : wanted) {
			if (existing.type().equals(trade.type()) && existing.id().equals(trade.id())) {
				return;
			}
		}
		wanted.add(trade);
		ModConfig.save();
	}

	@Override
	public boolean method_25404(class_11908 event) {
		if (event.comp_4795() == GLFW.GLFW_KEY_ENTER && !this.results.isEmpty()) {
			addWanted(this.results.get(0).trade());
			return true;
		}
		return super.method_25404(event);
	}

	@Override
	public void method_25419() {
		ModConfig.save();
		super.method_25419();
	}

	private static String labelOf(DesiredTrade trade) {
		if (trade.type().equals("enchantment")) {
			class_310 mc = class_310.method_1551();
			if (mc.field_1687 != null) {
				var lookup = mc.field_1687.method_30349().method_30530(class_7924.field_41265);
				var holder = lookup.method_10223(class_2960.method_60654(trade.id()));
				if (holder.isPresent()) {
					return holder.get().comp_349().comp_2686().getString();
				}
			}
			return trade.id();
		}
		var item = class_7923.field_41178.method_63535(class_2960.method_60654(trade.id()));
		if (item != class_1802.field_8162) {
			return new class_1799(item).method_7964().getString();
		}
		return trade.id();
	}
}