package dev.easytrade.config;

import it.unimi.dsi.fastutil.objects.Object2IntMap;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1887;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.class_9304;
import net.minecraft.class_9334;

public record DesiredTrade(String type, String id, int level) {

	public boolean matches(class_1799 output) {
		if (output.method_7960()) {
			return false;
		}
		if (this.type.equals("item")) {
			class_2960 key = class_7923.field_41178.method_10221(output.method_7909());
			return key != null && key.toString().equals(this.id);
		}
		if (this.type.equals("enchantment")) {
			class_9304 enchantments = output.method_31574(class_1802.field_8598)
				? output.method_58695(class_9334.field_49643, class_9304.field_49385)
				: output.method_58657();
for (Object2IntMap.Entry<class_6880<class_1887>> entry : enchantments.method_57539()) {
				class_5321<class_1887> key = entry.getKey().method_40230().orElse(null);
				if (key != null && key.method_29177().toString().equals(this.id) && (this.level <= 0 || entry.getIntValue() >= this.level)) {
					return true;
				}
			}
		}
		return false;
	}
}