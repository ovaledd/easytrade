package dev.easytrade;

import dev.easytrade.config.ModConfig;
import dev.easytrade.gui.TradeSelectScreen;
import dev.easytrade.tracker.TradeWatcher;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import org.lwjgl.glfw.GLFW;

public class EasyTradeClient implements ClientModInitializer {

	public static final String MOD_ID = "easytrade";

	private static class_304 openMenuKey;

	@Override
	public void onInitializeClient() {
		ModConfig.load();

		class_304.class_11900 category = class_304.class_11900.method_74698(class_2960.method_60655(MOD_ID, "category"));
		openMenuKey = new class_304("key.easytrade.menu", GLFW.GLFW_KEY_F7, category);
		KeyBindingHelper.registerKeyBinding(openMenuKey);

		ClientTickEvents.END_CLIENT_TICK.register(EasyTradeClient::onTick);
		HudElementRegistry.attachElementAfter(
			VanillaHudElements.SUBTITLES,
			class_2960.method_60655(MOD_ID, "overlay"),
			(graphics, deltaTracker) -> TradeWatcher.render(graphics));
	}

	private static void onTick(class_310 client) {
		if (openMenuKey.method_1436()) {
			client.method_29970(new TradeSelectScreen());
		}
		TradeWatcher.tick(client);
	}
}