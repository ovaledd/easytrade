package dev.easytrade.tracker;

import java.util.List;
import net.minecraft.class_1799;

public record PeekData(
	String title,
	String levelText,
	String itemName,
	String price,
	String mainCost,
	class_1799 mainIcon,
	class_1799 costA,
	class_1799 costB,
	List<OfferLine> lines,
	boolean matched,
	long seenAtTick) {

	public record OfferLine(String name, class_1799 output, boolean match, String price) {
	}
}