package dev.easytrade.mixin;

import dev.easytrade.tracker.TradeWatcher;
import net.minecraft.class_10260;
import net.minecraft.class_11909;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_490;
import net.minecraft.class_507;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_10260.class)
public class AbstractContainerScreenMixin {

	@Shadow
	private class_507<?> recipeBookComponent;

	@Inject(method = "render", at = @At("TAIL"))
	private void easytrade$renderOverlay(class_332 graphics, int mouseX, int mouseY, float delta,
		CallbackInfo ci) {
		if ((Object) this instanceof class_490) {
			class_437 self = (class_437) (Object) this;
			int left = this.recipeBookComponent.method_2595(self.field_22789, 176);
			TradeWatcher.renderInventoryOverlay(graphics, left, (self.field_22790 - 166) / 2, 176);
		}
	}

	@Inject(method = "mouseClicked", at = @At("HEAD"), cancellable = true)
	private void easytrade$handleOverlayClick(class_11909 event, boolean doubleClicked,
		CallbackInfoReturnable<Boolean> cir) {
		if ((Object) this instanceof class_490
			&& TradeWatcher.handleInventoryClick((int) event.comp_4798(), (int) event.comp_4799())) {
			cir.setReturnValue(true);
		}
	}
}