package dev.easytrade.mixin;

import dev.easytrade.tracker.TradeWatcher;
import net.minecraft.class_332;
import net.minecraft.class_465;
import net.minecraft.class_492;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_465.class)
public class ContainerScreenToastMixin {

	@Inject(method = "render", at = @At("TAIL"))
	private void easytrade$renderPinToast(class_332 graphics, int mouseX, int mouseY, float delta,
		CallbackInfo ci) {
		if ((Object) this instanceof class_492) {
			TradeWatcher.renderToast(graphics);
		}
	}
}