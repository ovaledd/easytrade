package dev.easytrade.mixin;

import dev.easytrade.tracker.TradeWatcher;
import net.minecraft.class_310;
import net.minecraft.class_3917;
import net.minecraft.class_3943;
import net.minecraft.class_3944;
import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_634.class)
public class ClientPacketListenerMixin {

	@Inject(method = "handleMerchantOffers", at = @At("TAIL"))
	private void easytrade$onMerchantOffers(class_3943 packet, CallbackInfo ci) {
		TradeWatcher.onOffersReceived();
	}

	@Inject(method = "handleOpenScreen", at = @At("HEAD"), cancellable = true)
	private void easytrade$protectOpenScreen(class_3944 packet, CallbackInfo ci) {
		class_310 mc = class_310.method_1551();
		if (!TradeWatcher.isPeeking() || packet.method_17593() != class_3917.field_17340 || mc.field_1724 == null) {
			return;
		}
		TradeWatcher.openPeekContainer(packet.method_17592());
		ci.cancel();
	}
}