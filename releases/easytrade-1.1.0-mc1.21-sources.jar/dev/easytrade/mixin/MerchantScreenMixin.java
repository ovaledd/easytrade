package dev.easytrade.mixin;

import dev.easytrade.tracker.TradeWatcher;
import net.minecraft.class_11909;
import net.minecraft.class_1916;
import net.minecraft.class_492;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_492.class)
public class MerchantScreenMixin {

	@Shadow
	private int scrollOff;

	@Inject(method = "mouseClicked", at = @At("HEAD"), cancellable = true)
	private void easytrade$pinOnRightClick(class_11909 event, boolean doubleClick,
		CallbackInfoReturnable<Boolean> cir) {
		if (event.method_74245() != 1) {
			return;
		}
		class_492 screen = (class_492) (Object) this;
		int xo = (screen.field_22789 - 176) / 2;
		int yo = (screen.field_22790 - 166) / 2;
		int mx = (int) event.comp_4798();
		int my = (int) event.comp_4799();
		for (int i = 0; i < 7; i++) {
			int bx = xo + 5;
			int by = yo + 18 + i * 20;
			if (mx >= bx && mx < bx + 88 && my >= by && my < by + 20) {
				class_1916 offers = screen.method_17577().method_17438();
				int index = i + this.scrollOff;
				if (index >= 0 && index < offers.size()) {
					TradeWatcher.pinOffer(offers.get(index));
				}
				cir.setReturnValue(true);
				return;
			}
		}
	}
}