package dev.easytrade.mixin;

import dev.easytrade.tracker.TradeWatcher;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_3988;
import net.minecraft.class_636;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_636.class)
public class MultiPlayerGameModeMixin {

	@Inject(method = "interact", at = @At("HEAD"))
	private void easytrade$onManualInteract(class_1657 player, class_1297 entity,
		class_1268 hand, CallbackInfoReturnable<class_1269> cir) {
		if (!TradeWatcher.isPeekInteract() && entity instanceof class_3988) {
			TradeWatcher.onPlayerInteract();
		}
	}
}